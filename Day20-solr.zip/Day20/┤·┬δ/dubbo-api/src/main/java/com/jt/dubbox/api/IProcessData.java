package com.jt.dubbox.api;

public interface IProcessData {
	public String hello(String name);
}
