package com.jt.web.factory;

import java.util.Calendar;

public class NewInstanceFactory {
	
	//实例工厂
	public Calendar getCalendar(){
		
		return Calendar.getInstance();
	}
}
