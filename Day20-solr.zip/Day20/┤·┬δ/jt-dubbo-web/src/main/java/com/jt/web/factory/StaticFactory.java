package com.jt.web.factory;

import java.util.Calendar;

public class StaticFactory {
	
	//静态方法
	public static Calendar getCalendar(){
		
		return Calendar.getInstance();
	}
}
